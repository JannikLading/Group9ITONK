﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Delopgaveprojekt.Constants
{
    public class Constants
    {
        public const string sqlConnectionString = "server=laptop-2vtij9g0; database=ITONK_ass1_gr9;";// providerName=System.Data.sqlClient";
    }   
}
