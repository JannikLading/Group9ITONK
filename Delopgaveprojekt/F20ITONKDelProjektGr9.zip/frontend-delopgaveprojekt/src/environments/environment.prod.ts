export const environment = {
  production: true,
  ENDPOINT: {
    TOOL: "http://35.195.97.193:1337/api/Vaerktoej",
    TOOLBOX: "http://35.195.97.193:1337/api/Vaerktoejskasse",
    CRAFTSMAN: "http://35.195.97.193:1337/api/Haandvaerker"
  }
};
